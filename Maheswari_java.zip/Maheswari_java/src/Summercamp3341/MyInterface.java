package Summercamp3341;

import java.util.Scanner;

interface MyInterface{
	
   public void display();
   
   public void display(String name, int age);
}


