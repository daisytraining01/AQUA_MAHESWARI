package Summercamp3341;

public class Sample1 {

	private String name;
	private int Empno;
	

	 
	public String getName() {
	    return name;
	  }
	  
public int getEmpno() {
	return Empno;
}

	  public void setName(String newName) {
     name = newName;
}
	  public void setEmpno(int Rollno)
	  {
		  Empno = Rollno;
	  }
	  
	  
	  
}
