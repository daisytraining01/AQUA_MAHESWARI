package Summercamp3341;

public class Sample2 extends Sample1{

	
	
	public static void main(String[] args) {
		
		Sample2 obj= new Sample2();
		
		obj.setName("mahes");
		obj.setEmpno(101);
		System.out.println("EmpName:" +obj.getName());
		System.out.println("Rollno:" +obj.getEmpno());

		
		}
}


/*
 EmpName:mahes
Rollno:101
 */