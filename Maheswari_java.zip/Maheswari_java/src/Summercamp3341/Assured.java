package Summercamp3341;
import java.util.Scanner;

public class Assured {

	public static void main(String[] args) {
	    
		System.out.println("program");
		            String s1,s2;
		            String str = "REST ASSURED";  
		            String str1 = str.substring(0, 4);
		            String str2 = str.substring(4, 12);
		            String str3 = str1.substring(0, str1.length() - 2);
		            String str4 = str3.concat(str2);
		            System.out.println("Removing the characters--> ST: "+str4);
		            System.out.println("Comparison of two strings");
		            Scanner s=new Scanner(System.in);
		            System.out.println("Enter First string :");
		            s1 =s.nextLine();
		    
		            System.out.println("Enter Second string :");
		            s2 =s.nextLine();

		           if(s1.equals(s2))
		           {
		               System.out.println("Strings are equal");
		           }
		           else
		           {
		               System.out.println("Strings are not equal");
		             
		           }   
		          	            
		        }  
		}

/* program
Removing the characters--> ST: RE ASSURED
Comparison of two strings
Enter First string :
 rose
Enter Second string :
rose
Strings are not equal	*/ 

